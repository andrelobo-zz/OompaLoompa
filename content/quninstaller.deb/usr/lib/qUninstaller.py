#!/usr/bin/python
# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'window.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!
#
# App creator: Jakub Zieliński (Poland)
# My email: kuba.zielinski2001@wp.pl

from PyQt4 import QtCore, QtGui

import threading
from threading import Thread
import commands
import glob
from xdg.Config import icon_theme
import os.path

import subprocess


from os.path import exists
from __builtin__ import str
from posix import remove
import time
from PyQt4.Qt import QWidget#, QFormBuilder

from multiprocessing import Process
import sys

global __icons__
__icons__ = "true"

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

__language__ = "retranslateUienglish"
global __firstrun__
__firstrun__ = "true"


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName(_fromUtf8("MainWindow"))
        MainWindow.resize(704, 402)
        MainWindow.setMinimumSize(QtCore.QSize(704, 402))
        MainWindow.setMaximumSize(QtCore.QSize(704, 402))
        MainWindow.setLayoutDirection(QtCore.Qt.LeftToRight)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8("/usr/share/icons/revi-uninstaller.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        MainWindow.setWindowIcon(icon)
        
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        
        
        self.myListWidget = QtGui.QListWidget(self.centralwidget)
        self.myListWidget.setGeometry(QtCore.QRect(30, 20, 631, 281))
        self.myListWidget.setObjectName(_fromUtf8("myListWidget"))
        self.myListWidget.setSortingEnabled(True)
        
        

		
        
        self.pushButton = QtGui.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(30, 320, 87, 27))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        
        self.checkBox = QtGui.QCheckBox(self.centralwidget)
        self.checkBox.setGeometry(QtCore.QRect(580, 320, 89, 22))
        self.checkBox.setChecked(True)
        self.checkBox.setTristate(False)
        self.checkBox.setObjectName(_fromUtf8("checkBox"))
        
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtGui.QStatusBar(MainWindow)
        self.statusbar.setObjectName(_fromUtf8("statusbar"))
        MainWindow.setStatusBar(self.statusbar)
        self.menuBar = QtGui.QMenuBar(MainWindow)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 704, 27))
        self.menuBar.setObjectName(_fromUtf8("menuBar"))
        self.menuAppMGr = QtGui.QMenu(self.menuBar)
        self.menuAppMGr.setObjectName(_fromUtf8("menuAppMGr"))
        self.menuAbout = QtGui.QMenu(self.menuBar)
        self.menuAbout.setObjectName(_fromUtf8("menuAbout"))
        self.menuLanguages = QtGui.QMenu(self.menuBar)
        self.menuLanguages.setObjectName(_fromUtf8("menuLanguages"))
        MainWindow.setMenuBar(self.menuBar)
        
        self.menuSettings = QtGui.QMenu(self.menuBar)
        self.menuSettings.setObjectName(_fromUtf8("menuSettings"))
        
        self.updatebutton = QtGui.QAction(MainWindow)
        self.updatebutton.setObjectName(_fromUtf8("updatebutton"))
        self.actionExit = QtGui.QAction(MainWindow)
        self.actionExit.setObjectName(_fromUtf8("actionExit"))
        self.actionAbout = QtGui.QAction(MainWindow)
        self.actionAbout.setObjectName(_fromUtf8("actionAbout"))
        self.actionEnglish = QtGui.QAction(MainWindow)
        self.actionEnglish.setObjectName(_fromUtf8("actionEnglish"))
        self.actionPolish = QtGui.QAction(MainWindow)
        self.actionPolish.setObjectName(_fromUtf8("actionPolish"))
        self.actionArabic = QtGui.QAction(MainWindow)
        self.actionArabic.setObjectName(_fromUtf8("actionArabic"))
        self.actionEnglish_2 = QtGui.QAction(MainWindow)
        self.actionEnglish_2.setObjectName(_fromUtf8("actionEnglish_2"))
        self.actionPolski = QtGui.QAction(MainWindow)
        self.actionPolski.setObjectName(_fromUtf8("actionPolski"))
        self.actionArabic_2 = QtGui.QAction(MainWindow)
        self.actionArabic_2.setObjectName(_fromUtf8("actionArabic_2"))
        
        

        
        
        self.menuAppMGr.addAction(self.updatebutton)
        self.menuAppMGr.addAction(self.actionExit)
        self.menuAbout.addAction(self.actionAbout)
        self.menuLanguages.addAction(self.actionEnglish_2)
        self.menuLanguages.addAction(self.actionPolski)
        self.menuLanguages.addAction(self.actionArabic_2)
        
        self.actionIcons = QtGui.QAction(MainWindow)
        self.actionIcons.setCheckable(True)
        self.actionIcons.setChecked(True)
        self.actionIcons.setObjectName(_fromUtf8("actionIcons"))
        self.menuSettings.addAction(self.actionIcons)
        
        self.menuBar.addAction(self.menuAppMGr.menuAction())
        self.menuBar.addAction(self.menuLanguages.menuAction())
        self.menuBar.addAction(self.menuAbout.menuAction())

        if __firstrun__ == "true":
            self.retranslateUi(MainWindow, __icons__, __language__, __firstrun__)
          
            
        QtCore.QObject.connect(self.updatebutton, QtCore.SIGNAL(_fromUtf8("activated()")), lambda: self.refreshlist(__icons__))
        QtCore.QObject.connect(self.actionExit, QtCore.SIGNAL(_fromUtf8("activated()")), MainWindow.close)
        QtCore.QObject.connect(self.pushButton, QtCore.SIGNAL(_fromUtf8("clicked()")), self.uninstallapp)
        QtCore.QObject.connect(self.actionAbout, QtCore.SIGNAL(_fromUtf8("activated()")), self.about)
        QtCore.QObject.connect(self.checkBox, QtCore.SIGNAL(_fromUtf8("stateChanged(int)")), self.icons)
        
        QtCore.QObject.connect(self.actionPolski, QtCore.SIGNAL(_fromUtf8("activated()")), self.retranslateUiPolish)
        QtCore.QObject.connect(self.actionEnglish_2, QtCore.SIGNAL(_fromUtf8("activated()")), self.retranslateUienglish)
        QtCore.QObject.connect(self.actionArabic_2, QtCore.SIGNAL(_fromUtf8("activated()")), self.retranslateUiArabic)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def about(self):
        
        Dialog3 = QtGui.QDialog()
        u = About_Dialog()
        u.setupUi(Dialog3)
        

        Dialog3.exec_()
    
    def icons(self):
          
        if self.checkBox.isChecked():
            global __icons__
            __icons__ = "true"
            
        else:
            global __icons__
            __icons__ = "false"
            
        self.myListWidget.clear()
        self.retranslateUi(MainWindow, __icons__, __language__, __firstrun__)
        
        
        
    def refreshlist(self, __icons__):
        print __icons__ + "----------------"
        self.myListWidget.clear()
        self.retranslateUi(MainWindow, __icons__, __language__, __firstrun__)
        
    
    
    def uninstallapp(self):
        
        __cho__ = self.myListWidget.currentItem().text()
       
        __cho__ = str(__cho__)
              
        __chofile__ = commands.getstatusoutput( "cat /tmp/applist.ls | grep -m 1 '" + __cho__ + "'")
 
        __chofile__ = str(__chofile__)
        __chofile__ = __chofile__[:-3]
        __chofile__ = __chofile__[__chofile__.find("`"):]
         
        __chofile__ = __chofile__.replace("`", "")

        __apppkg__ = commands.getstatusoutput("dpkg -S " + __chofile__)
        
        __apppkg__ = str(__apppkg__)
        
        __apppkg__ = __apppkg__[:__apppkg__.find(":")]
        __apppkg__ = __apppkg__.replace("(0, '", "")
   
        commands.getstatusoutput("rm /tmp/app.info && touch /tmp/app.info")
        writ = open("/tmp/app.info","a") #writ is a file object for write
        writ.writelines(__apppkg__)
          
        writ.close()        
     
        print ( "'" + __apppkg__ + "'" + ' will removed')
        
        global __apppkg__
        
        
        commands.getstatusoutput("rm /tmp/pkgname.info && touch /tmp/pkgname.info")
        writ = open("/tmp/pkgname.info","a") #writ is a file object for write
        writ.writelines(__apppkg__)
        
        Dialog = QtGui.QDialog()
        u = Ui_Dialog()
        u.setupUi(Dialog)

        Dialog.exec_()
        
        
               

        if __info__ == "False":
            self.refreshlist(__icons__)
            
            
        MainWindow.show()
        commands.getstatusoutput("rm /tmp/cancel.info")
            
       
            
        
        
    def retranslateUi(self, MainWindow, __icons__, __language__, __firstrun__):
        MainWindow.setWindowTitle(_translate("MainWindow", "qUninstaller", None))
              
        
        
        __output__ = ""
        __appname__ = ""
        __appicon__ = ""
        __firstrun__ = "false"
        
        commands.getstatusoutput("rm /tmp/applist.ls && touch /tmp/applist.ls")
        for __output__ in glob.glob("/usr/share/applications/*.desktop"):
            
            __appname__ = commands.getoutput("cat " + __output__ +  " | grep -m 1 Name=")
            
            __appicon__ = commands.getoutput("cat " + __output__ +  " | grep -m 1 Icon=")
            __nodisplay__ = commands.getoutput("cat " + __output__ +  " | grep -m 1 NoDisplay=true")
            __settings__ = commands.getoutput("cat " + __output__ +  " | grep -m 1 Settings")
            
	   
                     
            __nosettings__ = ""
            
            __nosettings__ = str(__nosettings__)
            __settings__ = str(__settings__)
            
            __nodisplay__ = str(__nodisplay__)
            
            if  (__nodisplay__ == "" and __settings__ == __nosettings__):
                
                __appicon__ = str(__appicon__)
                __appicon__ = (__appicon__[5:])
                
            
            
                __appicon__ = str(__appicon__)
            
                __appname__ = str(__appname__)    
                
                  
                __appname__ = (__appname__[5:])
            
                
        
                
                
                
		print __appicon__                

                                
                
                writ = open("/tmp/applist.ls","a") #writ is a file object for write
                writ.writelines("'"  + __appname__ + "'" + '=' + "`" + __output__ + "`\n")
                
                writ.close()
                
                  
                
                
                item = QtGui.QListWidgetItem()
                
                if __icons__ == "true":
					if os.path.exists(__appicon__):
						icon = QtGui.QIcon()
						icon.addPixmap(QtGui.QPixmap(_fromUtf8(__appicon__)), QtGui.QIcon.Normal, QtGui.QIcon.Off)
						item.setIcon(icon)
					else:
						icon = QtGui.QIcon.fromTheme(_fromUtf8(__appicon__))
						
						item.setIcon(icon)
						
                        
						
					
                    
                
                
                                   
                    
                item.setText(__appname__)
                
                self.myListWidget.addItem(item)
            
            

            
        

        
        method_name1 = "self." + __language__ +"()"
        
        eval(method_name1)
        

        
    def retranslateUienglish(self):
        MainWindow.setWindowTitle(_translate("MainWindow", "qUninstaller", None))
        self.myListWidget.setWhatsThis(_translate("MainWindow", "<html><head/><body><p>Apps list</p></body></html>", None))
        self.pushButton.setText(_translate("MainWindow", "Uninstall", None))
        self.menuAppMGr.setTitle(_translate("MainWindow", "File", None))
        self.menuAbout.setTitle(_translate("MainWindow", "About", None))
        self.menuLanguages.setTitle(_translate("MainWindow", "Language", None))
        self.updatebutton.setText(_translate("MainWindow", "Refresh list", None))
        self.actionExit.setText(_translate("MainWindow", "Exit", None))
        self.actionAbout.setText(_translate("MainWindow", "About", None))
        self.actionEnglish.setText(_translate("MainWindow", "English", None))
        self.actionPolish.setText(_translate("MainWindow", "Polish", None))
        self.actionArabic.setText(_translate("MainWindow", "Arabic", None))
        self.actionEnglish_2.setText(_translate("MainWindow", "English", None))
        self.actionPolski.setText(_translate("MainWindow", "Polish", None))
        self.actionArabic_2.setText(_translate("MainWindow", "Arabic", None))
        self.checkBox.setText(_translate("MainWindow", "Icons", None))
        print ("Set language to english")
        MainWindow.setLayoutDirection(QtCore.Qt.LeftToRight)
        global __language__
        __language__ = "retranslateUienglish"
        
    def retranslateUiPolish(self):
        print ("Set language to polish")
        self.pushButton.setText(_translate("MainWindow", "Odinstaluj", None))
        self.menuAppMGr.setTitle(_translate("MainWindow", "Plik", None))
        self.menuAbout.setTitle(_translate("MainWindow", "O programie", None))
        self.menuLanguages.setTitle(_translate("MainWindow", "Język", None))
        self.updatebutton.setText(_translate("MainWindow", "Załaduj ponownie listę aplikacji", None))
        self.actionExit.setText(_translate("MainWindow", "Wyjdź", None))
        self.actionAbout.setText(_translate("MainWindow", "O programie", None))
        self.actionEnglish.setText(_translate("MainWindow", "Angielski", None))
        self.actionPolish.setText(_translate("MainWindow", "Polski", None))
        self.actionArabic.setText(_translate("MainWindow", "Arabski", None))
        self.actionEnglish_2.setText(_translate("MainWindow", "Angielski", None))
        self.actionPolski.setText(_translate("MainWindow", "Polski", None))
        self.actionArabic_2.setText(_translate("MainWindow", "Arabski", None))
        self.checkBox.setText(_translate("MainWindow", "Ikony", None))
        MainWindow.setLayoutDirection(QtCore.Qt.LeftToRight)
        global __language__
        __language__ = "retranslateUiPolish"
        
    def retranslateUiArabic(self):
        print ("Set language to arabic")
        self.pushButton.setText(_translate("MainWindow", "الغاء التثبيت", None))
        self.menuAppMGr.setTitle(_translate("MainWindow", "ملف", None))
        self.menuAbout.setTitle(_translate("MainWindow", "حول", None))
        self.menuLanguages.setTitle(_translate("MainWindow", "اللسان", None))
        self.updatebutton.setText(_translate("MainWindow", "تحديث القائمة", None))
        self.actionExit.setText(_translate("MainWindow", "خروج", None))
        self.actionAbout.setText(_translate("MainWindow", "حول", None))
        self.actionEnglish.setText(_translate("MainWindow", "الإنجليزية", None))
        self.actionPolish.setText(_translate("MainWindow", "بولندي", None))
        self.actionArabic.setText(_translate("MainWindow", "العربية", None))
        self.actionEnglish_2.setText(_translate("MainWindow", "الإنجليزية", None))
        self.actionPolski.setText(_translate("MainWindow", "بولندي", None))
        self.actionArabic_2.setText(_translate("MainWindow", "العربية", None))
        self.checkBox.setText(_translate("MainWindow", "الرموز", None))
        MainWindow.setLayoutDirection(QtCore.Qt.RightToLeft)
        global __language__
        __language__ = "retranslateUiArabic"
        
class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(424, 142)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth())
        Dialog.setSizePolicy(sizePolicy)
        Dialog.setMinimumSize(QtCore.QSize(424, 142))
        Dialog.setMaximumSize(QtCore.QSize(424, 142))
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8("/usr/share/icons/revi-uninstaller.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        Dialog.setWindowIcon(icon)
        self.listWidget = QtGui.QListWidget(Dialog)
        self.listWidget.setGeometry(QtCore.QRect(20, 50, 371, 31))
        self.listWidget.setObjectName(_fromUtf8("listWidget"))
        self.label = QtGui.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(20, 10, 251, 17))
        self.label.setObjectName(_fromUtf8("label"))
        self.pushButton = QtGui.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(310, 100, 87, 27))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.pushButton_2 = QtGui.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(200, 100, 87, 27))
        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))
        
        self.listWidget.addItem(__apppkg__)
        
        QtCore.QObject.connect(self.pushButton_2, QtCore.SIGNAL(_fromUtf8("clicked()")), lambda: self.cancelUi(Dialog))
        QtCore.QObject.connect(self.pushButton, QtCore.SIGNAL(_fromUtf8("clicked()")), lambda: self.uninstallapp(Dialog))
        
        
        method_name1 = "self." + __language__ +"(Dialog)"
        
        eval(method_name1)
        
        
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def uninstallapp(self, Dialog):
        
        Dialog.close()
        MainWindow.hide()
        
        
              
        Dialog2 = QtGui.QDialog()
        u = loading_Dialog()
        u.setupUi(Dialog2)
	Dialog2.exec_()
          
        
        global __info__
        __info__ = "False"
        
        MainWindow.show()
        
        
        
        
        
        

    def retranslateUienglish(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Remove package", None))
        self.label.setText(_translate("Dialog", "This package will be removed:", None))
        self.pushButton.setText(_translate("Dialog", "Ok", None))
        self.pushButton_2.setText(_translate("Dialog", "Cancel", None))
        Dialog.setLayoutDirection(QtCore.Qt.LeftToRight)
        
    def retranslateUiArabic(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "إزالة حزمة", None))
        self.label.setText(_translate("Dialog", "سيتم إزالة هذه الحزمة:", None))
        self.pushButton.setText(_translate("Dialog", "حسنا", None))
        self.pushButton_2.setText(_translate("Dialog", "إلغاء", None))
        Dialog.setLayoutDirection(QtCore.Qt.RightToLeft)
        
    def retranslateUiPolish(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Usuń pakiet", None))
        self.label.setText(_translate("Dialog", "Te pakiety zostaną usunięte:", None))
        self.pushButton.setText(_translate("Dialog", "Ok", None))
        self.pushButton_2.setText(_translate("Dialog", "Anuluj", None))
        Dialog.setLayoutDirection(QtCore.Qt.LeftToRight)

    def cancelUi(self, Dialog):
        global __info__
        __info__ = "true"
        Dialog.close()
        
   


class About_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(397, 248)
        Dialog.setMinimumSize(QtCore.QSize(397, 248))
        Dialog.setMaximumSize(QtCore.QSize(397, 248))
        self.pushButton = QtGui.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(150, 200, 87, 27))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.label = QtGui.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(60, 10, 291, 91))
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8("/usr/share/icons/revi-uninstaller.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        Dialog.setWindowIcon(icon)
        font = QtGui.QFont()
        font.setPointSize(14)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.listWidget = QtGui.QListWidget(Dialog)
        self.listWidget.setGeometry(QtCore.QRect(10, 90, 371, 81))
        self.listWidget.setObjectName(_fromUtf8("listWidget"))
        item = QtGui.QListWidgetItem()
        self.listWidget.addItem(item)
        item = QtGui.QListWidgetItem()
        self.listWidget.addItem(item)
        item = QtGui.QListWidgetItem()
        self.listWidget.addItem(item)
        item = QtGui.QListWidgetItem()
        self.listWidget.addItem(item)

        self.retranslateUi(Dialog)
        QtCore.QObject.connect(self.pushButton, QtCore.SIGNAL(_fromUtf8("clicked()")), Dialog.close)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        
    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "About", None))
        self.pushButton.setText(_translate("Dialog", "Ok", None))
        self.label.setText(_translate("Dialog", "Information about qUninstaller", None))
        __sortingEnabled = self.listWidget.isSortingEnabled()
        self.listWidget.setSortingEnabled(False)
        item = self.listWidget.item(0)
        item.setText(_translate("Dialog", "Program name: qUninstaller- program uninstaller for Linux", None))
        item = self.listWidget.item(1)
        item.setText(_translate("Dialog", "Creator: Jakub Zieliński (PL)", None))
        item = self.listWidget.item(2)
        item.setText(_translate("Dialog", "Copyright: /usr/share/doc/qUninstaller/copyright", None))
        item = self.listWidget.item(3)
        item.setText(_translate("Dialog", "Version: 1.1", None))
        self.listWidget.setSortingEnabled(__sortingEnabled)


class loading_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(471, 149)
        Dialog.setMinimumSize(QtCore.QSize(471, 149))
        Dialog.setMaximumSize(QtCore.QSize(471, 149))
        self.progressBar = QtGui.QProgressBar(Dialog)
        self.progressBar.setEnabled(True)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8("/usr/share/icons/revi-uninstaller.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        Dialog.setWindowIcon(icon)
        self.progressBar.setGeometry(QtCore.QRect(30, 50, 411, 21))
        self.progressBar.setMaximum(0)
        self.progressBar.setProperty("value", -1)
        self.progressBar.setObjectName(_fromUtf8("progressBar"))
        self.pushButton = QtGui.QPushButton(Dialog)
        self.pushButton.setEnabled(False)
        self.pushButton.setGeometry(QtCore.QRect(50, 100, 87, 27))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.label = QtGui.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(40, 10, 200, 31))
        self.label.setObjectName(_fromUtf8("label"))
        self.pushButton_2 = QtGui.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(340, 100, 87, 27))
        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))
	self.pushButton_2.setVisible(False)
	commands.getoutput("rm -f /tmp/done.info")
	self.threadclass = ThreadClass()
        self.threadclass.start()

	commands.getstatusoutput("rm -rf /tmp/done.info")

	method_name1 = "self." + __language__ +"(Dialog)"
        
        eval(method_name1)
        
	
	
        commands.getstatusoutput("echo pkexec sudo apt-get autoremove " + __apppkg__ + " -y \&\& touch /tmp/done.info > /tmp/removepkg.sh")
	subprocess.Popen(["sh", "/tmp/removepkg.sh"])

   	

        QtCore.QObject.connect(self.pushButton_2, QtCore.SIGNAL(_fromUtf8("clicked()")), Dialog.close)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
	QtCore.QObject.connect(self.threadclass, QtCore.SIGNAL("IS_CLOSE"), Dialog.close)

    def retranslateUienglish(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Uninstalling program", None))
        self.pushButton.setText(_translate("Dialog", "Cancel", None))
        self.label.setText(_translate("Dialog", "Uninstalling program ...", None))
        self.pushButton_2.setText(_translate("Dialog", "Close", None))
    def retranslateUiArabic(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "برنامج إلغاء", None))
        self.pushButton.setText(_translate("Dialog", "Cancel", None))
        self.label.setText(_translate("Dialog", "برنامج إلغاء ...", None))
        self.pushButton_2.setText(_translate("Dialog", "قريب", None))
	Dialog.setLayoutDirection(QtCore.Qt.RightToLeft)
    def retranslateUiPolish(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Odinstalowywanie programu", None))
        self.pushButton.setText(_translate("Dialog", "Anuluj", None))
        self.label.setText(_translate("Dialog", "Odinstalowywanie programu ...", None))
        self.pushButton_2.setText(_translate("Dialog", "Zamknij", None))
    	
    

class ThreadClass(QtCore.QThread):
    def __init__(self, parent = None):
        super(ThreadClass, self).__init__(parent)
    def run(self):
        while not os.path.exists("/tmp/done.info"):
            time.sleep(1)            
        else:
            self.emit(QtCore.SIGNAL("IS_CLOSE"))

if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    MainWindow = QtGui.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

